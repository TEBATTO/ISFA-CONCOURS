

library(dbscan) # me permettra d'entourer mes clusters que j'ai trouver à travers la fonction Hull
# 1) positionnement des points 

set.seed(665544)
n <-500 # Nombre d'individu
Coord<- cbind(
  x = runif(5, 0, 5) + rnorm(n, sd = 0.2),
  y = runif(5, 0, 5) + rnorm(n, sd = 0.2)
) # coordonnée des individus
plot(Coord[,1],Coord[,2],"p")
x<-Coord[,1]
y<-Coord[,2]



# 2) calcul des distances entre points 

Base1<-matrix(0,ncol = length(x),nrow = length(x))
system.time(
  for(i in 1:(length(x)-1)){
  for(j in (i+1):length(x)){
    Base1[j,i]<-sqrt((Coord[i,1]-Coord[j,1])^2 +
                      (Coord[i,2]-Coord[j,2])^2)
  }
    
}
)
(Base1<-Base1+t(Base1))



## determinons les valeurs Minpts et epsilon
#1) Valeur de Minpts =s+1

# 2) Valeur epsilon


# Cette fonction est une fonction qui determine le  s-voisin le plus proche de chaque observations
da<-NULL
s<-3 
eps<-function(s){
  
  for(i in 1:(ncol(Base1)-1)){
    
    f<-sort(Base1[,i])
    f<-f[!f==0]
    da[i]<-f[s]
  }
  return(da)
}

barplot(-sort(-eps(s)))#  ce barplot nous permettra de mieux choisir le epsilon. 
Base2<-matrix(0,ncol = length(x),nrow=length(x))




#  Mettre tous les voisins des differents points qui ont un rayon inferieur à epsilon// Et trouver les differents centraux.

epsi<--sort(-eps(s))[n-n*90/100] # au choix, mais cette valeur est une valeur optimale de epsilon

Centre1<-NULL
minPts<-s+1 #au choix mais cette valeur est une valeur optimale de minPts
system.time(
  for(i in 1:length(x)){
  Base2[1:length(which(Base1[,i]<=epsi)),i]<-which(Base1[,i]<=epsi)
  if(length(Base2[1:length(which(Base1[,i]<=epsi)),i][Base2[1:length(which(Base1[,i]<=epsi)),i]!=0])>=minPts){
    
    Centre1[i]<-i
    }
  
})


#  4) Creation de clusters( Verifier si les differents elements de chaque centraux sont  egalement des centraux)
if(length(Centre1)==0){
  " tous les individu sont des centraux"
}
(Centre2<-Centre1[!is.na(Centre1)])
a1<-matrix(0,ncol =length(Centre2),nrow=length(Centre2))
system.time(
  for(i in 1:length(Centre2)){
  
(z<-c(Centre2,Base2[,Centre2[i]]))
aa<-as.numeric(names(table(factor(z,levels =Centre2))[table(factor(z,levels =Centre2))==2]))
a1[1:length(aa),i]<-aa
  
  })



Cluster<-matrix(0,ncol=length(x),nrow=length(x))
d<-1
p<-1
dataa<-matrix(0,ncol=length(Centre2),nrow=length(Centre2))
dataa[1:length(Centre2),p]<-Centre2
a3<-(a1!=0)*1
a3<-apply(a3,2,sum)

if(length(which(a3==1))!=0){
  dd<-length(which(a3==1))
  Cluster[ ,1:dd]<-Base2[,Centre2[which(a3==1)]]
  Centre2<-Centre2[-which(a3==1)]
  a1<-a1[,-which(a3==1)]
 
}else(dd<-0)



  i<-d  # je prend le i ieme centraux
  a<-a1[,i][a1[,i]!=0][-Centre2[i]]# on prend les centraux ce trouvant dans le ieme centraux tout en supprimant le centraux auquel noous sommes. 
  l<-a1[,i][a1[,i]!=0] # l permet de prendre le centraux deja selectionné
  k<-length(a) 
  t<-1
  j<-0
  d<-1
  hu<-1:n
  
  li<-matrix(0,ncol=length(Centre2),nrow=length(Centre2))
     system.time(
       # Algorithme de DBSCAN     
       while(k!=0 & d!=0){
       
        
        vect<-as.vector(Base2[,a])[as.vector(Base2[,a])!=0] # selection les colonnes (Base2) des centraux se trouvant dans le centraux i(supprimé des 0).
        (vect<-unique(vect))
        (Vect2<-as.numeric(names(table(factor(l,levels=vect))[which(table(factor(l,levels=vect))==0)])))# Fait sortir tous les elts trouvé qui ne se trouve pas dans l où l sera mis à jour.
        
        ### ici on verifie si tous les elts de vect2 ne sont pas des centraux: k=0 sinon k=1 : il existe des centraux et evidemment ces centraux n'appartiennent pas a l.
        if(sum(table(factor(Centre2,levels=Vect2)))==0){
          k<-0
          res<-sort(unique(as.vector(Base2[,l])[as.vector(Base2[,l])!=0]))  
          Cluster[c(1:length(res)),dd+1]<-res
          li[1:length(l),p]<-l
          hu[Cluster[c(1:length(res)),dd+1][which(Cluster[c(1:length(res)),dd+1]!=0)]]=dd+1
          dd<-dd+1
          
       }else{
          Vect3<-as.numeric(names(table(factor(Vect2,levels=Centre2))[which(table(factor(Vect2,levels=Centre2))==1)]))
          k<-1
          l<-c(l,Vect3) # permet de stocker les centraux deja visité(qu'on a fait sorti)
          a<-Vect3 # permet de stocker les centraux qu'on a trouvé a la ieime iteration.
          
       }
        
        ###  Ici c'est une condition pour voir si on continu avec la boucle sur k ou non.
        if( k==0 && sum(table(factor(as.numeric(li[ ,1:p])[-which(as.numeric(li[,1:p])==0)],levels=Centre2)))!=length(Centre2)){ 
           p<-p+1
          z<-table(factor(as.numeric(li[ ,1:(p-1)]),levels=Centre2))
          if(length(as.numeric(names(z[which(z!=0)])))==n){
            Cluster<-as.matrix(1:n)
            break
          }
          z<-as.numeric(names(z[which(z==0)]))
          d<-which(Centre2==z[1])
          
        }else if(k!=0){
            d<-d
          }else(
            d<-0
            #
          )
        
        ### 
        if(k==0 & d!=0){
          a<-a1[,d][a1[,d]!=0][-Centre2[d]]
          l<-a1[,d][a1[,d]!=0]
          k<-length(a)
        }
     })
        


## Vrai tracer pour la fin . Aimé c'est  utiliser.

ze1<-NULL
 for(i in 1:n){
   ze1[i]<-arrayInd(which(Cluster==i),dim(Cluster))[2]
 }  
ze1[is.na(ze1)]<-0

# avant d'utiliser le ze1 il faut mettre en 0 les valeur aberrante.     
plot(Coord, col=ze1) # la strategie pour les couleur c'est d'associer chq individu a sa class.
points(Coord[ze1==0,], pch = 5, col = "grey")
hullplot(Coord,ze1,main="Formation des cluster")



  
  